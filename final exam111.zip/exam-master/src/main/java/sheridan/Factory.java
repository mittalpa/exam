/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sheridan;

/**
 *
 * @author palak
 */
public class Factory {
    private double discount;
    double DiscountByAmount;
        double DiscountByperctg ;
    private static Factory DiscountObject = null;

   
    
public void addFactory(){
    
}
public static Factory getInstance() {
if(DiscountObject==null)
{
    DiscountObject = new Factory();
}
return DiscountObject;
}
}
