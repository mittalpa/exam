/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sheridan;

/**
 *
 * @author palak
 */
public class Discount {
    
    public static void main(String args[])
	{
    
        double dollar;
        double amount;
        
	double DiscountByAmount =1000;
        double DiscountByperctg =25;  // 25 mean 25%			
	
	System.out.println ("DiscountByAmount= "+ DiscountByAmount);
        System.out.println("discount rate="+DiscountByperctg);
         
        dollar=100-DiscountByperctg;
 
	amount= (dollar*DiscountByAmount)/100;
 
	System.out.println("amount after discount="+amount);
 
	}

}
