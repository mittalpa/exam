/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sheridan;

/**
 *
 * @author palak
 */
public class UnitTestClass {
    public static double TwoSecarerio(double Size)
    {
        if(Size < 0){
            return 0;
        }
           else
        {
        return Size;
    }
    }
}

