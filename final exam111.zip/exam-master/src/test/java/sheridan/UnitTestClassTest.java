/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sheridan;

import static javax.swing.text.StyleConstants.Size;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author palak
 */
public class UnitTestClassTest {
    
    public UnitTestClassTest() {
    }
    
    @Before
    public void setUp() {
    }

    /**
     * Test of TwoSecarerio method, of class UnitTestClass.
     */
    @Test
    public void testTwoSecarerio() {
        System.out.println("TwoSecarerio");
        double Size = 0.0;
        double expResult = 0.0;
        double result = UnitTestClass.TwoSecarerio(Size);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    public void testValidateLength(){
        String pass = "MyPassword123";
        boolean result =UnitTestClass.TwoSecarerio(Size);
        assertEqual(true, result);
    }

    private void assertEqual(boolean b, boolean result) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
}
